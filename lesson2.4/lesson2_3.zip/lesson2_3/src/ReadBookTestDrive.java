public class ReadBookTestDrive {
    public static void main(String[] args) {
        ReadBook rb = new ReadBook();
        rb.startRead("Book");
    }
}
